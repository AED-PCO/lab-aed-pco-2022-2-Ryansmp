﻿
namespace WorkBJA
{
    internal class Aluno
    {
        public string Matrícula { get; set; }
        public string Nome { get; set; }
        public string Curso { get; set; }
    }
}
