﻿
using WorkBJA;

Queue<Aluno> FilaAluno = new Queue<Aluno>();

Aluno x;

// Inserção de Aluno na Lista

x = new Aluno();

x.Matrícula = "123";
x.Nome = "Gustavo Silveira";
x.Curso = "SI";

FilaAluno.Enqueue(x);

x = new Aluno();

x.Matrícula = "456";
x.Nome = "Denise Ferreira";
x.Curso = "Enfermagem";

FilaAluno.Enqueue(x);

x = new Aluno();

x.Matrícula = "789";
x.Nome = "Humberto da Silva Júnior";
x.Curso = "Engenharia Civil";

FilaAluno.Enqueue(x);

x = new Aluno();

x.Matrícula = "000";
x.Nome = "Paulo Brito";
x.Curso = "Direito";

FilaAluno.Enqueue(x);

Queue<Aluno>FilaInvertida= new Queue<Aluno>(FilaAluno.Reverse());  


int Qtde;

Qtde = FilaAluno.Count;

Console.WriteLine($"Existem {Qtde} Alunos na Fila...");

foreach (Aluno A in FilaAluno)
{
    Console.WriteLine($"\n{A.Nome} ({A.Matrícula})");
    Console.WriteLine($"Curso: {A.Curso}");
}

Console.WriteLine("\n");
Console.ReadKey();

Console.WriteLine("Fila invertida....");
foreach (Aluno A in FilaInvertida)
{
    Console.WriteLine($"\n{A.Nome} ({A.Matrícula})");
    Console.WriteLine($"Curso: {A.Curso}");
}

Console.ReadKey();