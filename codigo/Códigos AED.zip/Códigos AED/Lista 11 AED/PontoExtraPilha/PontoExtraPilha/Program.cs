﻿using PontoExtraPilha;
using System;

namespace MyApp 
{
    internal class Program
    {
     
        static void Main(string[] args)
        {

            Pilha minhapilha = new Pilha();

            minhapilha.inserir(5);
            minhapilha.inserir(56);
            minhapilha.inserir(84);
            minhapilha.inserir(758);
            minhapilha.inserir(123);
            minhapilha.inserir(789);
            minhapilha.inserir(487);


            minhapilha.mostrapilha();
            minhapilha.limpapilha();
            Console.ReadKey();



        }
    }
}