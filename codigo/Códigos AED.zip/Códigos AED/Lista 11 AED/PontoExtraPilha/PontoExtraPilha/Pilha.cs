﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PontoExtraPilha
{
    internal class Pilha
    {
        private Elemento topo;
        private Elemento aux;

        public int tamanho;

        public Pilha()
        {
            topo = null;
            tamanho = 0;
        }

        public void inserir(int valor)
        {
            Elemento novo = new Elemento();

            novo.num = valor;
            novo.prox = topo;
            topo = novo;

            tamanho++;
        }

        public void retirar(ref int x)
        {
            if (topo == null)
            {
                Console.Write("A pilha não possui nenhum elemento");
                Console.ReadKey();
            }
            else
            {
                x = topo.num;
                topo = topo.prox;
                tamanho--;
            }
        }
        public void mostrapilha()
        {

            if (topo == null)
            {
                Console.Write("A pilha não possui nenhum elemento");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine($"Elementos da pilha : {0}\n", tamanho);
                aux = topo;
                while (aux != null)
                {
                    Console.WriteLine($"{0}", aux.num);
                    aux=aux.prox;
                }
            }

        }

        public void limpapilha()
        {


            if (topo == null)
            {
                Console.Write("A pilha não tem elementos...");
                Console.ReadKey();
            }
            else
            {
                topo = null;
                tamanho = 0;
            }
        }


    }
}
