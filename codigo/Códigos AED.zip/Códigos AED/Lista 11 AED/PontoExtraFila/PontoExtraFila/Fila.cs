﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace PontoExtraFila
{
    internal class Fila
    {
        private Elemento inicio;
        private Elemento fim;
        private Elemento aux;

        public int tamanho;

        public Fila()
        {
            inicio = null;
            fim = null;
            tamanho = 0;
        }

        public void inserir(int valor)
        {
            Elemento novo = new Elemento();

            novo.num = valor;
            novo.prox = null;
            if (inicio == null)
            {
                inicio = novo;
                fim = novo;
            }
            else
            {
                fim.prox = novo;
                fim = novo;
            }
            tamanho++;
        }

        public void retirar(ref int x)
        {
            Console.Clear();

            if (inicio == null)
            {
                Console.WriteLine("A fila não possui nenhum elemento");
                Console.ReadKey();
            }

            else
            {
                x = inicio.num;
                inicio=inicio.prox;
                tamanho--;
            }
        }

        public void mostrafila()
        {
            Console.Clear();

            if (inicio == null)
            {
                Console.WriteLine("A fila não possui elementos");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine($"Elementos da fila{0}\n", tamanho);
                aux = inicio;

                while (aux != null)
                {
                    Console.WriteLine($"{0,3}", aux.num);
                    aux=aux.prox;
                }
                Console.ReadKey();
            }
            }

        public void limpafila()
        {
            if (inicio == null)
            {
                Console.WriteLine("A fila não possui elementos");
                Console.ReadKey();
            }
            else
            {
                inicio = null;
                tamanho = 0;
            }
        }

    }

}
