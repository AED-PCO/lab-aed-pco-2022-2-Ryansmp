﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PontoExtraFila
{
    internal class Elemento
    {
        public int num;
        public Elemento prox;

        public Elemento()
        {
            num = 0;
            prox = null;
        }

    }
}
