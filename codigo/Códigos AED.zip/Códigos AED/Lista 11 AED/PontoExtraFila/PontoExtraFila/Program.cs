﻿using PontoExtraFila;
using System;

namespace MyApp 
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Fila minhafila= new Fila();

            minhafila.inserir(10);
            minhafila.inserir(15);
            minhafila.inserir(24);
            minhafila.inserir(78);
            minhafila.inserir(94);
            minhafila.inserir(65);
            minhafila.mostrafila();
            Console.ReadKey();
        }
    }
}