﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Lab8Pilha;

namespace Lab8Pilha
{
    internal class Program
    {
        static void Main(string[] args)
        {
          Stack<Carro>documento = new Stack<Carro>();

            Carro x;  

            x = new Carro();       //Preenchendo as informações da class informações setadas na carro.cs.
            x.marca = "Fiat";
            x.cor = "Vermelho";
            x.modelo = "Uno";
            x.ano = 2010;
            documento.Push(x);

            x = new Carro();
            x.marca = "Ford";
            x.cor = "Azul";
            x.modelo = "Focus";
            x.ano = 2015;
            documento.Push(x);

            x = new Carro();
            x.marca = "Hyundai";
            x.cor = "Branco";
            x.modelo = "Hb20";
            x.ano = 2018;
            documento.Push(x);

            x = new Carro();
            x.marca = "Fiat";
            x.cor = "Preto";
            x.modelo = "Toro";
            x.ano = 2023;
            documento.Push(x);

            x = new Carro();
            x.marca = "Volkswagen";
            x.cor = "Verde";
            x.modelo = "Fusca";
            x.ano = 1996;
            documento.Push(x);

            x = new Carro();
            x.marca = "Fiat";
            x.cor = "Bege";
            x.modelo = "147";
            x.ano = 1980;
            documento.Push(x);

            x = new Carro();
            x.marca = "Fiat";
            x.cor = "Amarelo";
            x.modelo = "Coupé";
            x.ano = 1995;
            documento.Push(x);

            x = new Carro();
            x.marca = "Alfa Romeu";
            x.cor = "Vermelho";
            x.modelo = "Giulia Quadrifoglio";
            x.ano = 2023;
            documento.Push(x);

            int quantidade;

            quantidade = documento.Count;

            Console.Write("     Bem-Vindo    ");
            Console.Write("\n");
            Console.Write("Concessionária do Ryan");
            Console.Write("\n");
            Console.Write($"Existem {quantidade} carros em estoque");
            Console.Write("\n");
            Console.Write("Aperte qualquer tecla para prosseguir...");
            Console.ReadKey();
            Console.Clear();

            Console.Write("   Lista dos Carros em estoque   ");
            Console.WriteLine("\n");

            foreach (Carro c in documento)
            {
                Console.WriteLine($"  {c.marca} {c.modelo} {c.cor} {c.ano}  ");  //Exibir todos os elementos da pilha com suas respectivas informações
            }

            Console.WriteLine("\n");

            Console.ReadKey();
            Console.WriteLine($"O útimo carro a chegar na concessionária foi {documento.Peek().modelo} da marca {documento.Peek().marca}");//Mostra o último carro a entrar na pilha da concessionária
            Console.ReadKey();





        }
    }
}