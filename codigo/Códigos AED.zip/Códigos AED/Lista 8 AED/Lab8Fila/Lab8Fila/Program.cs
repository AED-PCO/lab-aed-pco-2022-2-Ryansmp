﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace Lab8Fila
{

    class Program
    {
        static void Main()
        {
            Queue<Aluno> FilaAluno = new Queue<Aluno>();

            Aluno x;

            // Inserção de Aluno na Lista

            x = new Aluno();

            x.Matrícula = "123";
            x.Nome = "Gustavo Silveira";
            x.Curso = "SI";

            FilaAluno.Enqueue(x);

            x = new Aluno();

            x.Matrícula = "456";
            x.Nome = "Denise Ferreira";
            x.Curso = "Enfermagem";

            FilaAluno.Enqueue(x);

            x = new Aluno();

            x.Matrícula = "789";
            x.Nome = "Humberto da Silva Júnior";
            x.Curso = "Engenharia Civil";

            FilaAluno.Enqueue(x);

            x = new Aluno();

            x.Matrícula = "000";
            x.Nome = "Paulo Brito";
            x.Curso = "Direito";

            FilaAluno.Enqueue(x);

            int Qtde;

            Qtde = FilaAluno.Count;

            Console.WriteLine($"Existem {Qtde} Alunos na Fila...");

            foreach (Aluno A in FilaAluno)
            {
                Console.WriteLine($"\n{A.Nome} ({A.Matrícula})");
                Console.WriteLine($"Curso: {A.Curso}");
            }

            Console.ReadKey();

            FilaAluno.Dequeue();

            Console.WriteLine("\n");

            foreach (Aluno A in FilaAluno)
            {
                Console.WriteLine($"\n{A.Nome} ({A.Matrícula})");
                Console.WriteLine($"Curso: {A.Curso}");
            }

            Console.WriteLine($"\n\nAluno no INÍCIO da Fila: {FilaAluno.Peek().Nome}");

            Console.ReadKey();

            x = FilaAluno.ElementAt(1);

            Console.WriteLine($"\nAluno na Posição 1 da Fila: {x.Nome}");

            Console.ReadKey();
        }
    }
}





