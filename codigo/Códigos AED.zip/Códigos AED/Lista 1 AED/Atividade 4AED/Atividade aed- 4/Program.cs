﻿using System;

namespace MyApp //Note:Faça um programa que receba os elementos de uma matriz de 5 linhas por 3 colunas.
    //mostre a soma dos elementos de cada uma das linhas e das colunas da matriz.
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[,] matriz = new int[5, 3];
            int valor;
            

            for (int i = 0; i < matriz.GetLength(0); i++)
                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    Console.Write($"Informes valors para preencher a matriz na posição º{i+1}  º{j+1}.:");
                    valor = int.Parse(Console.ReadLine());
                    matriz[i, j] = valor;
                  
                }

            int[] somalinha = new int[5];


            for (int i = 0; i < matriz.GetLength(0); i++)
                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    somalinha[i] += matriz[i, j];  
                }


                for (int i=0; i<matriz.GetLength(0); i++)
                {
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                    Console.Write("|" + somalinha[i] + "|");
                }

            Console.ReadKey();

        }
    }
}