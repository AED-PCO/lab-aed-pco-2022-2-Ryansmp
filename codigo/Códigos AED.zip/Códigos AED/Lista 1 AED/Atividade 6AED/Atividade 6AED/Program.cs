﻿using System;

namespace MyApp // Note:Faça um programa que chame uma função capaz de calcular xy, sendo x e y inteiros.
    //utilizando passagem de parâmetro por referência.
{
    internal class Program
    {
        public static double potencia(int x, int y)
        {
            double resultado;

             return resultado = Math.Pow(x, y);
  
        }

        static void Main(string[] args)
        {
            double resultado;

            Console.Write("informe o valor de X...:");
            int x=int.Parse(Console.ReadLine());

            Console.Write("informe o valor de Y...:");
            int y = int.Parse(Console.ReadLine());

            resultado = potencia(x, y);
            Console.WriteLine($"O resultado de {x} elevado por {y} e {resultado}");

            Console.ReadKey();
        }
    }
}