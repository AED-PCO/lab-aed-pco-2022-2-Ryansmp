﻿using System;

internal class Program
{
    private static void Main(string[] args) 
        //Note:Faça um programa que receba os elementos de dois vetores A e B cada um com 5 posições.
        //considerando que nenhum dos vetores possui elementos repitidos.

        //crie um vetor C resultante que possua os elementos comuns entre A e B.
        //crie um vetor D resultante que contenha os elementos de A que não existam B.
        
        ///Muitos erros.
    {
        int[] VetA = new int[5];
        int[] VetB = new int[5];
        int[] VetC = new int[5];
        int[] VetD = new int[15];

        for (int i = 0; i < 5; i++)
        {
            Console.Write($"informe para preencher o vetor na posição º{i + 1} ");
            VetA[i] = int.Parse(Console.ReadLine());
        }

        for (int j = 0; j < 5; j++)
        {
            Console.Write($"informe para preencher o vetor na posição º{j + 1} ");
            VetB[j] = int.Parse(Console.ReadLine());
        }

        for (int i = 0; i < 5; i++)//Vetor A
            for (int j = 0; j < 5; j++)//Vetor B
                if (VetA[i] == VetB[j])
                {
                    for (int k = 0; k < 5; k++)
                    {
                        VetC[k] = VetA[i];
                    }
                }


        for (int i = 0; i < 5; i++)//Vetor A
            for (int j = 0; j < 5; j++)//Vetor B
                if (VetA[i] != VetB[j])
                {
                    for (int l = 0; l < VetD.Length; l++)
                    {
                        VetD[l] = VetA[i];
                    }
                }


        for (int i = 0; i < 5; i++)//Vetor A
            for (int j = 0; j < 5; j++)//Vetor B
                if (VetB[j] != VetA[i])
                {
                    for (int l = 0; l < VetD.Length; l++)
                    {
                        VetD[l] = VetB[j];
                    }
                }



        for (int k = 0; k < 5; k++)
            Console.Write("|" + VetC[k]);

        for (int l = 0; l < VetD.Length; l++)
            Console.Write("|" + VetD[l]);

        Console.ReadKey();
    }
}