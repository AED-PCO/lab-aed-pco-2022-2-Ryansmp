﻿using System;

namespace MyApp // Note:Faça um programa que chame uma função capaz de calcular o fatorial de um número inteiro.
{
    internal class Program
    {public static int fatorial(int x)
        {
            int fat = 0;

            if (x == 1)
                return 1;

            else
            {
                return fat = x * fatorial(x - 1);
            }

            
        }
        static void Main(string[] args)
        {
            int resultado;

            Console.Write("Informe um número...:");
            int num= int.Parse(Console.ReadLine());


            resultado = fatorial(num);
            Console.Write($"O fatorial de {num} e {resultado}");
            Console.ReadKey();
        }
    }
}