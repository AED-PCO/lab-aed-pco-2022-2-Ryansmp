﻿using System;

namespace MyApp // Note: actual namespace depends on the project name.
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int soma, i;

            Console.Write("Informe um Número...");
            int num = int.Parse(Console.ReadLine());



           for ( i = 1; i < num; i++)
            {
                soma = 0; 
                for (int j = 1; j < i; j++)
                {
                    if (i % j == 0)
                    {
                        soma = soma + j;
                    }
                }
            }
           if (soma == i)
            {
                Console.WriteLine();
            }
            

            Console.ReadKey();
        }
    }
}