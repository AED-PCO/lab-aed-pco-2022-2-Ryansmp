﻿
using System;

static int buscabinaria(int[]vetor, int inicio, int fim, int busca)
{
    int meio = inicio - (inicio - fim) / 2;

   
        if (inicio > fim)
        {
        return -1;
        }

        else if (busca == vetor[meio]) //Melhor caso.
        {
        return meio;
        }
        else if (busca > vetor[meio])//Caso o meio for > que o meio.
        {
        inicio = meio + 1;
          return buscabinaria(vetor, inicio, fim, busca);
        }
        else//Caso o meio for < que o meio.
        {
        fim = meio - 1;
          return buscabinaria(vetor, inicio, fim, busca);

        }
      

}


int[]Vetor= {1,3,4,9,10,11,12,13,18,20,25,37,40,59,79};

Console.Write("Escolha um dos valores do vetor para achar sua posição--->");
for (int i = 0; i < Vetor.Length; i++)
{
    Console.Write("|" + Vetor[i] + "|");
}
Console.WriteLine("\n");
int busca = int.Parse(Console.ReadLine());
Console.ReadKey();


int inicio = 0;
int fim = Vetor.Length - 1;


int resultado = buscabinaria(Vetor, inicio, fim, busca);

if (resultado == -1)
{
    Console.Write("O valor escolhido para busca não esta no vetor");
}
else
{
    Console.Write(resultado);
}
Console.ReadKey();
