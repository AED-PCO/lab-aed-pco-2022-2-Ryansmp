﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8Pilha
{
    internal class Carro
    {

        //quais informações vão ter "dentro da class"
        public string marca { get; set; }
        public string cor { get; set; }
        public string modelo { get; set; }
        public int ano { get; set; }

    }
}
