﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8Lista
{
    internal class Aluno
    {
        public string Matrícula { get; set; }
        public string Nome { get; set; }
        public string Curso { get; set; }
    }
}
