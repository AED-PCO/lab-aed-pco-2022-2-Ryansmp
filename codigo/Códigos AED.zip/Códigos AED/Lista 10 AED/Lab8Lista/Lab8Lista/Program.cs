﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace Lab8Lista
{

    class Program
    {
        static void Main()
        {
            List<Aluno> ListaAluno = new List<Aluno>();
            
            Aluno x;

            // Inserção de Aluno na Lista

            x = new Aluno();

            x.Matrícula = "123";
            x.Nome = "Gustavo Silveira";
            x.Curso = "SI";

            ListaAluno.Add(x);

            x = new Aluno();

            x.Matrícula = "456";
            x.Nome = "Denise Ferreira";
            x.Curso = "Enfermagem";

            ListaAluno.Add(x);

            x = new Aluno();

            x.Matrícula = "789";
            x.Nome = "Humberto da Silva Júnior";
            x.Curso = "Engenharia Civil";

            ListaAluno.Add(x);

            x = new Aluno();

            x.Matrícula = "000";
            x.Nome = "Paulo Brito";
            x.Curso = "Direito";

            ListaAluno.Add(x);

            // Contagem de Elementos

            Console.WriteLine($"A Lista de Alunos possui {ListaAluno.Count} elementos...");

            // Listagem de Alunos

            foreach (Aluno A in ListaAluno)
            {
                Console.WriteLine($"\n{A.Nome} ({A.Matrícula}");
                Console.WriteLine($"Curso: {A.Curso}");
            }

            Console.ReadKey();

            Console.Clear();

            string xMat;
            int Posição;

            Console.Write("Digite uma Matrícula: ");
            xMat = Console.ReadLine();

            Posição = ProcuraLista(ListaAluno, xMat);

            if (Posição >= 0)
            {
                Console.WriteLine($"\nAluno encontrado na Lista na Posição {Posição}.");

                x = ListaAluno.ElementAt(Posição);

                int Linha;

                Console.Write($"\nMatrícula do Aluno: {x.Matrícula}");

                Linha = Console.CursorTop;
                Console.SetCursorPosition(20, Linha);

                x.Matrícula = Console.ReadLine();

                Console.Write($"Nome do Aluno.....: {x.Nome}");

                Linha = Console.CursorTop;
                Console.SetCursorPosition(20, Linha);

                x.Nome = Console.ReadLine();

                ListaAluno.RemoveAt(Posição);

                ListaAluno.Insert(Posição, x);

                Console.Clear();

                Console.WriteLine("\n");

                foreach (Aluno A in ListaAluno)
                {
                    Console.WriteLine($"\n{A.Nome} ({A.Matrícula}");
                    Console.WriteLine($"Curso: {A.Curso}");
                }
            }
            else
            {
                Console.Write("\nAluno não encontrado...");
            }

            Console.ReadKey();
        }

        static int ProcuraLista(List<Aluno> Lista, string xMat)
        {
            int Pos = -1;

            foreach (Aluno A in Lista)
            {
                if (A.Matrícula == xMat)
                {
                    Pos = Lista.IndexOf(A);
                    break;
                }
            }

            return Pos;
        }
    }
}





