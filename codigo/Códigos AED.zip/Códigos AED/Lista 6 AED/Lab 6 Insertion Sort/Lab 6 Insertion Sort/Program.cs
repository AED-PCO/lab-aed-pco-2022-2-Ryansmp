﻿static int[] SortArray(int[] vetor, int length)
{
    for (int i = 1; i < length; i++)
    {
        var key = vetor[i];
        var flag = 0;

        for (int j = i - 1; j >= 0 && flag != 1;)
        {
            if (key < vetor[j])
            {
                vetor[j + 1] = vetor[j];
                j--;
                vetor[j + 1] = key;
            }
            else flag = 1;
        }
    }

    return vetor;
}

int[] vetor = { 10, 54, 5, 15, 200, 150, 180 };
int[] vetor2 = { 10, 54, 5, 15, 200, 150, 180 };
int tam = vetor.Length;
int[]resultado=new int[tam];

resultado = SortArray(vetor, tam);

Console.Write("O vetor origial--->");
for (int j = 0; j < vetor2.Length; j++)
{
    Console.ForegroundColor = ConsoleColor.Red;
    Console.Write("|"+vetor2[j]+"|");
}
Console.ForegroundColor = ConsoleColor.White;
Console.Write("\n");
Console.WriteLine("Aperte qualquer tecla para prosseguir...");
Console.ReadKey();
Console.Clear();

Console.Write("\n");

Console.Write("O vetor após a ordenação--->");
for (int i = 0; i < resultado.Length; i++)
{
    Console.ForegroundColor = ConsoleColor.Green;
    Console.Write("|" + resultado[i] + "|");
}

Console.Write("\n");
Console.ForegroundColor = ConsoleColor.White;
Console.Write("Aperte um botão para sair...");
Console.ReadKey();