﻿
Console.Write("Informe uma frase pra inverter...");
string fraseUser= Console.ReadLine();

string fraseinvertida = new string(fraseUser.Reverse().ToArray());//Inverter a frase.

Console.Clear();
Console.Write("                 TEXTO              ");
Console.Write("\n");

Console.ForegroundColor=ConsoleColor.Red;
Console.Write("Frase original--->");
Console.Write(fraseUser);

Console.WriteLine("\n");

Console.ForegroundColor = ConsoleColor.Green;
Console.Write("Frase invertida--->");
Console.Write(fraseinvertida);

Console.ReadKey();
Console.Clear();


//Algumas tentativas que achei em java mas nenhuma da certo🤬🤬🤬	



///Meu plano inciail era ir do inicio do vetor(frases) do fim ao inicio até o fim e atribuir os valores ao
///vetor2(frases2) atribuindo ao "contrario" mas não sei se o erro e o escopo do primeiro for ou não atribuição 
///ao segundo for.

string[] frases = { "Frase para inverter" };
string[] frases2 = { "  " };

//for (int i = 999; i > frases.Length; i--)//erro
//for(int j = 0; j < frases2.Length; j++)//erro
//  frases2[j] = frases[i];//erro

//for (int i = frases.Length - 1; i >= 0; i--)

//for (int j = frases2.Length - 1; j >= 0; j--)

//frases2[j] = frases[i];

//int tamanhoriginal = frases.Length;
//string[] frases2 = new string[tamanhoriginal];
//int tamanhoVetororiginal = tamanhoriginal;

//for (int i = 0; i < tamanhoriginal; i++)

    //frases[i] = frases[tamanhoriginal];
    //Console.Write(frases2[i]);


for (int i = 0; i < frases.Length; i++)
{
    for (int j = 0; j < frases2.Length; j++)
    {
        frases2[j] = frases[i];
    }
}



for (int i = frases2.Length - 1; i >= 0; i--)
//Achei o escopo certo na internet mas não funciona 😠😠😠😠😠😠, achei que iria dar certo desta
//forma percorrendo ele ao contrario e exibindo mas não foi.
{
    Console.Write(frases2[i]);
}



    Console.ReadKey();