﻿//ºEscreva um método recrusivo que retorne o fatorial de um número.

 static int Fatorial(int n)
{

    int resultado;

    if (n == 1)
    {
        return 1;
    }

    else
         resultado = n * (Fatorial(n - 1));

    return resultado;
}

Console.Write("Informe o número o qual você deseja descobrir o fatorial...:");
int num = int.Parse(Console.ReadLine());


int fator =Fatorial(num);
Console.Clear();
Console.ForegroundColor = ConsoleColor.Green;
Console.Write($"O fatorial do Número {num} e {fator}");
Console.ReadKey();