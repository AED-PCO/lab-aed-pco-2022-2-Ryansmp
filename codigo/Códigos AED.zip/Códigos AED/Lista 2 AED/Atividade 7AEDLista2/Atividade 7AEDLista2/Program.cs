﻿//ºEscreva um método recursivo que que receba uma frase e retorne a mesma frase, sem nenhuma vogal.


static string removevogal(string frase)
{
    
}





Console.Write("Informe uma frase...");
string frase=Console.ReadLine();

removevogal(frase);

Console.ReadKey();