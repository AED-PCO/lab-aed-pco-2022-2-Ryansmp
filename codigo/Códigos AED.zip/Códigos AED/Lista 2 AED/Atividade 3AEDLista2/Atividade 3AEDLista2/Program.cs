﻿//ºUma multiplicação pode ser vista como uma sequência de somas.Escreva um método recrusivo que realize
//a multiplicação de dois números inteiros,A e B, recebidos por parâmetro.

static int multiplica(int valor, int x)
{
    if (x == 1)
        return valor;

    if (x > 0)
        return multiplica(valor, x - 1)+valor;
    
    else
        return multiplica(valor, x + 1)+valor;

}

   

Console.Write("Informe o valor de A...:");
int a = int.Parse(Console.ReadLine());

Console.Write("Informe o valor de B...:");
int b = int.Parse(Console.ReadLine());

int resultado = 0;
resultado = multiplica(a, b);
Console.Write(resultado);
Console.ReadKey();
