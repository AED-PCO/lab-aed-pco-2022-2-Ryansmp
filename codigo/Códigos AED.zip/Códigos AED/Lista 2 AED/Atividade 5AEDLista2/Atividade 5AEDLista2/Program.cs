﻿//ºEscreva um método recursivo que realize a potenciação entre dois números inteiros,A e B, recebidos por
//Parâmetro. seu método deve, portanto, retornar o resultado de aB.


static int potencia(int x, int y)
{
    int resultado = 0;

    if (y == 1)
        return x;

    else
        resultado = x * (potencia(x, y-1));

    return resultado;
}

Console.Write("Informe o valor de X...");
int x = int.Parse(Console.ReadLine());

Console.Write("Informe o valor de Y...");
int y = int.Parse(Console.ReadLine());

int resultado;
resultado = potencia(x, y);

Console.Write(resultado);
Console.ReadKey();