﻿//ºEscreva um método recursivo que calcule a soma dos elementos de um valor par de um vetor de números
//inteiros positivos.

//Fiz mas só depois lembrei que tinha que ser recursivo...
static int somavetorpar(int[] vetor)
{
    Random x=new Random();
    int[]vetor2=new int[vetor.Length];

    for (int i = 0; i < vetor.Length; i++)
    {
        vetor[i] = x.Next(1,200);
    }//preenche o vetos com números aleatórios.

    for (int i = 0; i < vetor.Length; i++)
    {
        if (vetor[i] % 2 == 0)
        {
            vetor2[i] = vetor[i];
        }
    }//separa pares.

    for (int i = 0; i < vetor2.Length; i++)
    {
        Console.Write("|" + vetor2[i]);
    }//exibi vetor de pares.

    int soma = 0;
    for (int i = 0; i < vetor2.Length; i++)
    {
        soma += vetor2[i];
    }//soma vetor.

    return soma;
}

static void criavetor(int tamanho)
{
    int[]vetor=new int[tamanho];
    Random x= new Random();

    for (int i = 0; i < vetor.Length; i++)
    {
        vetor[i]=x.Next(1,300);
    }

}

static int somavetorparecursivo(int tamanho)
{
    int[] vetor = new int[tamanho];
    int[] vetorpares = new int[tamanho];
    Random x=new Random();

    for (int i = 0; i < vetor.Length; i++)
    {
        vetor[i] = x.Next(1, 400);
    }//Preencher vetor
     
    for (int i = 0; i < vetor.Length; i++)
    {
        if (vetor[i] % 2 == 0)
        {
            vetorpares[i]=vetor[i];
        }
    }//separ os números pares

        
}



Console.Write("Informe o tamanho do Vetor...");
int tamanho=int.Parse(Console.ReadLine());

int[] vetor = new int[tamanho];

int resultado = somavetorpar(vetor);
 //somavetorparecursivo(tamanho);
Console.Write("\n");
Console.Write("A soma dos elementos pares do vetor e --->");
Console.Write(resultado);
Console.Write("\n");
Console.ReadKey();
