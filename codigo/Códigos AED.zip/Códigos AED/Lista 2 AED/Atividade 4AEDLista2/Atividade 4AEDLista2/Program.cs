﻿//ºEscreva um método recursivo que receba uma frase e uma letra como parâmetro.Este método deve retornar
//a quantidade de ocorrência desta letra nesta frase.


 //static int ocorrencia(char letra, string frase) //Não cosegui fazer recursivamente.
{
    
 

}





Console.Write("Informe uma frase..."); //Solícita a frase pro usuário.
string frase = Console.ReadLine();
var countador = frase.Split("a");



Console.Write(frase);
Console.WriteLine();
Console.WriteLine(Convert.ToString(countador.Length-1));

Console.ReadKey();
