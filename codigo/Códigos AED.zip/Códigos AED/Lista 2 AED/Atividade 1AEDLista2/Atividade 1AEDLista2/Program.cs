﻿
//ºExercício:Definição recursiva da série de Fibonacci.

 static int Fibonacci(int num)//Peguei na internet...
{
    int resultado;

    if (num < 1)
    {
        return 1;
    }
    else
    {
        resultado= Fibonacci(num - 2) + Fibonacci(num - 1);
    }
    return resultado;
}

 static int Fibonacci2(int n)
{
    int a = 2;
    int b = 3;

    for (int i = 0; i < n; i++)
    {
        int temp = a;
        a = b;
        b = temp + b;
    }
    return a;
}//Não recursivo foi o jeito que conseguir fazer 


Console.Write("Informe um número...:");
int num = int.Parse(Console.ReadLine());

int resultado = Fibonacci(num);
Console.Write($"O númeoro que na {num}º casa da sequência  e ---->");
Console.Write("\n");
Console.Write($"{resultado}");

Console.Write("\n");
for (int i = 0; i < num; i++)
{
    Console.Write("|"+Fibonacci2(i)+"|");
}
Console.ReadKey();