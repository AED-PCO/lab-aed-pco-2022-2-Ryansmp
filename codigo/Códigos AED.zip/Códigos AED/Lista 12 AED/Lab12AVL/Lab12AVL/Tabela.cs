﻿using System;

public abstract class Tabela
{

    public abstract
    string IdParaBusca();
} // fim classe tabela
