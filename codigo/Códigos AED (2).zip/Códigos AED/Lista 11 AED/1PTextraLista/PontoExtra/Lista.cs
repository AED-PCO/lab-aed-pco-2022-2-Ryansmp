﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace PontoExtra
{
    internal class Lista
    {

        private Elemento Início;
        private Elemento Fim;
        private Elemento Aux;

        public Lista()
        {
            Início = null;
            Fim = null;
        }

        public void InserirInício(int x)
        {
            Elemento Novo = new Elemento();

            Novo.Valor = x;

            if (Início == null)
            {
                Início = Novo;
                Fim = Novo;
            }
            else
            {
                Novo.Próx = Início;
                Início.Ant = Novo;

                Início = Novo;
            }
        }

        public void InserirFinal(int x)
        {
            Elemento Novo = new Elemento();

            Novo.Valor = x;

            if (Início == null)
            {
                Início = Novo;
                Fim = Novo;
            }
            else
            {
                Fim.Próx = Novo;
                Novo.Ant = Fim;
                Fim = Novo;
            }
        }

        public void MostrarListaINIFIM()
        {
            Aux = Início;

            while (Aux != null)
            {
                Console.Write($"{Aux.Valor,6}");

                Aux = Aux.Próx;
            }
        }

        public void MostrarListaFIMINI()
        {
            Aux = Fim;

            while (Aux != null)
            {
                Console.Write($"{Aux.Valor,6}");

                Aux = Aux.Ant;
            }
        }

        public void Retirar(int x)
        {
            Aux = Início;

            while (Aux != null)
            {
                if (Aux.Valor == x)
                {
                    if (Aux == Início)
                    {
                        Início = Aux.Próx;

                        Início.Ant = null;

                        Aux = Início;
                    }
                    else if (Aux == Fim)
                    {
                        Fim = Fim.Ant;

                        Aux = null;
                    }
                    else
                    {
                        Aux.Ant.Próx = Aux.Próx;

                        Aux.Próx.Ant = Aux.Ant;

                        Aux = Aux.Próx;
                    }
                }
                else
                {
                    Aux = Aux.Próx;
                }

            }
        }

        public void EsvaziarLista()
        {
            Início = null;
            Fim = null;
        }
    }
}
