﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Collections;
using PontoExtra;

namespace WorkBJA
{

    class Program
    {
        static void Main()
        {
            Lista MinhaLista = new Lista();

            MinhaLista.InserirInício(8);

            MinhaLista.InserirInício(78);

            MinhaLista.InserirInício(563);

            MinhaLista.InserirInício(45);

            MinhaLista.InserirInício(4);

            MinhaLista.InserirInício(19);

            MinhaLista.InserirInício(11);

            MinhaLista.InserirFinal(8);

            MinhaLista.InserirFinal(10);

            MinhaLista.InserirFinal(16);

            MinhaLista.MostrarListaINIFIM();

            Console.ReadKey();

            Console.WriteLine("\n\n");

            MinhaLista.MostrarListaFIMINI();

            Console.WriteLine("\n\n");

            Console.Write("      Escolha um número pra ser removido...:");
            int remove = int.Parse(Console.ReadLine());


            Console.WriteLine("\n\n");
            Console.Write("      Escolha (1) para adicionar no início ou (2)para adicionar no fim...:");
            int inserir= int.Parse(Console.ReadLine());

            if (inserir == 1)
            {
                Console.Write("      Escolha um número pra adicionar no início...");
                int um = int.Parse(Console.ReadLine());
                MinhaLista.InserirFinal(um);
            }
            else
            {
                Console.Write("      Escolha um número pra adicionar no fim...");
                    int dois = int.Parse(Console.ReadLine());
                MinhaLista.InserirFinal(dois);
            }

            MinhaLista.Retirar(remove);

            Console.ReadKey();

            Console.WriteLine("\n\n");

            MinhaLista.MostrarListaFIMINI();

            Console.ReadKey();
        }
    }
}





