﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PontoExtra
{
    internal class Elemento
    {
        public int Valor;
        public Elemento Próx;
        public Elemento Ant;

        public Elemento()
        {
            Valor = 0;
            Próx = null;
            Ant = null;
        }
    }
}
